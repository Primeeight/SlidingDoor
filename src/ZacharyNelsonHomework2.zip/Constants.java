public class Constants {
	public static final int buffersize = 13;
	public static final int lostframes = 3;
	public static final int timeout = 1000;
}

